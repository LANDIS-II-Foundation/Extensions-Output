using System.Reflection;

[assembly: AssemblyDescription("Maximum Species Age - Output Plug-in")]
[assembly: AssemblyProduct("Landis-II")]
[assembly: AssemblyCompany("UW-Madison, Forest Landscape Ecology Lab")]
[assembly: AssemblyCopyright("Copyright 2005 University of Wisconsin")]
